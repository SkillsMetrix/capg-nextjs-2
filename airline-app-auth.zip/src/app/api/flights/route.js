import { NextResponse } from "next/server"

const JSON_BASE='http://localhost:3001'
export async function POST(request) {
    const body = await request.json()
    const res= await fetch(`${JSON_BASE}/flights`,{
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    })

    const data= await res.json()
    if(!res.ok) return NextResponse.json({error: 'Upstream failed'},{status:502})
        return NextResponse.json(data,{status:201})
}