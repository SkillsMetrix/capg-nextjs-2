import Link from "next/link";

export default function DashboardLayout({ children }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <aside style={{
        width: 240,
        padding: 20,
        background: "#f3f4f6",
        borderRight: "1px solid #e5e7eb"
      }}>
        <h3 style={{ marginTop: 0 }}>Dashboard</h3>
        <nav>
          <ul style={{ listStyle: "none", padding: 0 }}>
            <li><Link href="/dashboard">Overview</Link></li>
            <li style={{ marginTop: 8 }}><Link href="/dashboard/settings">Settings</Link></li>
            <li style={{ marginTop: 8 }}><Link href="/dashboard/reports">Reports</Link></li>
          </ul>
        </nav>
      </aside>

      <main style={{ flex: 1, padding: 24 }}>
        <header style={{ marginBottom: 16 }}>
          <h2>Admin Area</h2>
        </header>

        <section>
          {children}
        </section>
      </main>
    </div>
  );
}
