"use client"
import AddUser from "./AddUser"
import Footer from "./Footer"
import Header from "./Header"


function MainApp(){
    const Header_Message=' NextJS User CRUD App'
    const FOOTER_Message=' User CopyRight Mesage'
    return (
        <div>
            <Header hm={Header_Message} />
            <AddUser/>
             
            <Footer fm={FOOTER_Message} />
        </div>
    )
}
export default MainApp