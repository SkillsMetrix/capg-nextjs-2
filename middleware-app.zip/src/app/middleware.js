import { getUserFromToken } from "@/lib/auth"
import { NextResponse } from "next/server"

export function middleware(req){

    const token = req.cookies.get('token')?.value
    const user= token? getUserFromToken() : null

    const {pathname}= req.nextUrl

    // protect admin routes

    if(pathname.startsWith('/admin')){
        if(!user || user.role !=='admin'){
            return NextResponse.redirect(new URL('/unauth',req.url))
        }
    }
    // protect user routes

    if(pathname.startsWith('/user')){
        if(!user || user.role !=='user'){
            return NextResponse.redirect(new URL('/unauth',req.url))
        }
    }
    return NextResponse.next()
}
export const config={
    matcher: ["/admin/:path","/user/:path"]
}