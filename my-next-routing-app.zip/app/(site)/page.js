export default function Home() { return <h1>🏠 Welcome to the Public Site (Static)</h1>; }
