'use client'

export  default function PassengerError({error}){
    return (
        <div className="card">
            <h3>Error Loading Passenger Details</h3>
            <pre>{String(error)}</pre>
        </div>
    )
}