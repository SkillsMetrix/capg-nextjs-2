
  

export default function Blog({params}) {
  const {slug}= params
  return (
    <div>
 <strong> {slug}</strong>   blog Page 🌬️
     </div>
  )
}