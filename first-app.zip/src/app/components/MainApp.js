"use client";
import AddUser from "./AddUser";
import Footer from "./Footer";
import Header from "./Header";
import styles from "../styles/App.module.css";
import { useUsers } from "../hooks/useUsers";
import UserList from "./Users";
import { useState } from "react";
import EditUser from "./EditUser";

function MainApp() {
  const [editing, setEditing] = useState(null);

  const handleRequestEdit = (user) => setEditing(user);
  const handleCancelEdit = () => setEditing(null);
  const handleSaveEdit = (id, patch) => {
    updateUser(id, patch);
    setEditing(null);
  };

  const { users, addUser, deleteUser, updateUser } = useUsers();
  const Header_Message = " NextJS User CRUD App";
  const FOOTER_Message = " User CopyRight Mesage";
  return (
    <div>
      <Header hm={Header_Message} />
      <main className={styles.container}>
        <div className={styles.grid}>
          <div className={styles.card}>
            <AddUser onAdd={addUser} />
          </div>
          <div className={styles.card}>
            {editing ? (
              <div>
                <EditUser
                  user={editing}
                  onSave={handleSaveEdit}
                  onCancel={handleCancelEdit}
                />
              </div>
            ) : (
              <UserList
                onRequestEdit={handleRequestEdit}
                users={users}
                onDelete={deleteUser}
              />
            )}
          </div>
        </div>
        <hr />
        <br />
        <Footer fm={FOOTER_Message} />
      </main>
    </div>
  );
}
export default MainApp;
