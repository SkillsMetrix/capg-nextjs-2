export default function About() { return <h1>ℹ️ About (Static)</h1>; }
