export default function Docs({ params }) {
  const slugArray = params?.slug;
  const isIndex = !slugArray || slugArray.length === 0;
  const path = isIndex ? "/docs" : `/docs/${slugArray.join("/")}`;
  return (
    <div>
      {isIndex ? (
        <>
          <p>
            This is Docs Page 🌬️, Path: <code>{path}</code>{" "}
          </p>

          <h3>Docs Details Here....!</h3>
          <ul>
            <li>
              <a href="/docs/intro">/docs/intro</a>   </li><br/>
             <li>  <a href="/docs/getting-ready/setup">/docs/getting-ready/setup</a> </li><br/>
             <li>  <a href="/docs/api/auth/login">/docs/api/auth/login</a> </li><br/>
            
          </ul>
          <p>
            THis is using <strong>Catch All Feature</strong> Segment:
            <code>app/docs/[[...slug]]/page.js</code>
          </p>
        </>
      ) : (
        <>
          <p>
            {" "}
            Showing Doc for : <strong>{path}</strong>
          </p>
          <section>
            <h2>{slugArray[slugArray.length - 1]}</h2>
            <p> PLaceholder content</p>
            <details>
              <summary> Raw Params </summary>
                <pre>{JSON.stringify({ slug: slugArray }, null, 2)}</pre>
             
            </details>
          </section>
        </>
      )}
    </div>
  );
}
