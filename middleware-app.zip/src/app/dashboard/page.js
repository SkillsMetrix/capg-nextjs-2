 
'use client'

import { useEffect, useState } from "react"

export default function DashBoard() {
  const [role,setRole]= useState(null)

  useEffect(()=>{
    setRole("admin")
  },[])
  return (
    <div >
      {role === 'admin' && <button>Manage User</button>}
       {role === 'user' && <button>Limited Access</button>}
      </div>
  )}