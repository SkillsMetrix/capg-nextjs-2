'use client'

import { useState } from 'react'
import styles from '../styles/App.module.css'
export default function AddUser(){

    const [username,setUsername]= useState('')
    const [email,setEmail]= useState('')
    const [city,setCity]= useState('')


    return (
        <form className={styles.form}>
            <input placeholder='Enter Username' value={username} onChange={(e)=> setUsername(e.target.value)} className={styles.input}></input>
              <input placeholder='Enter Email' value={email} onChange={(e)=> setEmail(e.target.value)} className={styles.input}></input>
                <input placeholder='Enter City' value={city} onChange={(e)=> setCity(e.target.value)} className={styles.input}></input>
        </form>
    )
}
