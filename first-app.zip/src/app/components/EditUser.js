'use client'

import { useState } from 'react'
import styles from '../styles/App.module.css'
export default function EditUser({user,onSave,onCancel}){

    const [username,setUsername]= useState(user.username)
    const [email,setEmail]= useState(user.email)
    const [city,setCity]= useState(user.city)

const handleSave=(e)=>{
    e.preventDefault()
    if(!username.trim() || !email.trim() || !city.trim()) return alert('All Fields are required')
        onSave(user.id,{username:username.trim(),email:email.trim(),city:city.trim()})
        
}
return (
        <form className={styles.formInline} onSubmit={handleSave}>
            <input  value={username} onChange={(e)=> setUsername(e.target.value)} className={styles.smallInput}></input>
              <input value={email} onChange={(e)=> setEmail(e.target.value)} className={styles.smallInput}></input>
                <input  value={city} onChange={(e)=> setCity(e.target.value)} className={styles.smallInput}></input>
                <div className={styles.controls}>
        <button className={styles.buttonSmall}>Update</button>
             <button type='button' onClick={onCancel} className={styles.secondaryButton}>Cancel</button>
             </div>
        </form>
    )
}
