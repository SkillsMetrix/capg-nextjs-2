 

export default function Home() {
  return (
    <div>
      welcome admin
      </div>
  )}