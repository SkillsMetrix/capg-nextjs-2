import Navigation from "../../components/Navigation";

export default function SiteLayout({ children }) {
  return (
    <div>
      <header>
        <Navigation />
      </header>

      <main style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
        {children}
      </main>

      <footer style={{ textAlign: "center", padding: 24, color: "#6b7280" }}>
        © {new Date().getFullYear()} My Next App — Public Site
      </footer>
    </div>
  );
}
