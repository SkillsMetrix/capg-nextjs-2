'use client'
import styles from '../styles/App.module.css'

export default function UserItem({user}){

    return (
        <div className={styles.item}>
            <div>
                <strong>{user.username}</strong> -{user.email} - {user.city}
            </div>
            <div className={styles.itemControls}>
                <button className={styles.small}>Edit</button>
                <button className={styles.dangerSmall}>Delete</button>
            </div>
        </div>
    )
}