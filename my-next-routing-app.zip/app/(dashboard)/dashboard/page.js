export default function DashboardHome() {
  return (
    <div>
      <h1>📊 Dashboard Home</h1>
      <p>This page is wrapped by <code>app/(dashboard)/layout.js</code>.</p>
    </div>
  );
}
