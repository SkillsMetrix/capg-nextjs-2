"use client";

import { useEffect, useState } from "react";
import { readFromStorage, writeToStorage } from "../lib/storage";

export function useUsers() {
  const [users, setUsers] = useState([]);
// called during load time
  useEffect(() => {
    setUsers(readFromStorage);
  }, []);
// called only when state changes
  useEffect(() => {
    writeToStorage(users);
  }, [users]);

  const addUser = (user) => {
    setUsers((prev) => [...prev, { ...user, id: Date.now().toString() }]);
    console.log(...users);
  };
  return { users, addUser };
}
