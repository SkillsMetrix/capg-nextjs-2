import PassengerCard from "../components/PassengersCard";
import { fetchPassengers } from "../lib/api";

export default async function Passengers() {
  const passengers = await fetchPassengers();
  return (
    <div>
      <p>Passengers Details</p>

      <div className="grid">
        {passengers.map((p) => (
          <PassengerCard key={p.id} passenger={p} />
        ))}
      </div>
    </div>
  );
}
