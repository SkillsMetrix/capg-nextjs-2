"use client";
import AddUser from "./AddUser";
import Footer from "./Footer";
import Header from "./Header";
import styles from "../styles/App.module.css";
import { useUsers } from "../hooks/useUsers";
import UserList from "./Users";

function MainApp() {
  const {users,addUser} = useUsers()
  const Header_Message = " NextJS User CRUD App";
  const FOOTER_Message = " User CopyRight Mesage";
  return (
    <div>
      <Header hm={Header_Message} />
      <main className={styles.container}>
        <div className={styles.grid}>
          <div className={styles.card}>
            <AddUser onAdd={addUser} />
          </div>
          <div>
            <UserList users={users}/>
          </div>
        </div>
        <hr/>
        <br/>
        <Footer fm={FOOTER_Message} />
      </main>
    </div>
  );
}
export default MainApp;
