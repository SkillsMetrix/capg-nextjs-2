"use client";

import { useEffect, useState } from "react";
import { readFromStorage, writeToStorage } from "../lib/storage";

export function useUsers() {
  const [users, setUsers] = useState([]);
// called during load time
  useEffect(() => {
    setUsers(readFromStorage);
  }, []);
// called only when state changes
  useEffect(() => {
    writeToStorage(users);
  }, [users]);

  const updateUser=(id,patch)=>{
    setUsers(prev => prev.map(u => (u.id ===id ? {...u,...patch}: u)))
  }
  const deleteUser=(id) =>{
    setUsers(prev => prev.filter(u => u.id !==id))
  }
  const addUser = (user) => {
    setUsers((prev) => [...prev, { ...user, id: Date.now().toString() }]);
    console.log(...users);
  };
  return { users, addUser , deleteUser,updateUser};
}
