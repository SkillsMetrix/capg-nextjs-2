// components/ProgrammaticNav.js
"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

export default function ProgrammaticNav() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [slug, setSlug] = useState("nextjs-routing");
  const [docsPath, setDocsPath] = useState("getting-started/setup");

  async function goToBlog() {
    // simple dynamic route push
    router.push(`/blog/${slug}`);
  }

  function replaceWithBlog() {
    // replace current entry (no back to previous)
    router.replace(`/blog/${slug}`);
  }

  function goToDocsCatchAll() {
    // catch-all example: segments joined by '/'
    const path = `/docs/${docsPath}`;
    router.push(path);
  }

  function goToDashboardReports() {
    // route group -> still a normal URL
    router.push(`/dashboard/reports`);
  }

  function goBack() {
    router.back();
  }

  function goForward() {
    router.forward();
  }

  function doPrefetch() {
    // prefetch resources for a route (useful before push)
    router.prefetch(`/blog/${slug}`);
  }

  function refreshPage() {
    // re-fetch server data on the current page
    router.refresh();
  }

  function pushWithTransition() {
    // use useTransition to show pending UI for UX
    startTransition(() => {
      router.push(`/blog/${slug}`);
    });
  }

  return (
    <div style={{ border: "1px solid #e5e7eb", padding: 12, borderRadius: 8 }}>
      <h3>Programmatic Navigation Demo</h3>

      <div style={{ marginBottom: 8 }}>
        <label>
          Blog slug:{" "}
          <input value={slug} onChange={(e) => setSlug(e.target.value)} />
        </label>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
        <button onClick={goToBlog}>Push → /blog/{slug}</button>
        <button onClick={replaceWithBlog}>Replace → /blog/{slug}</button>
        <button onClick={pushWithTransition} disabled={isPending}>
          {isPending ? "Navigating…" : `Transition → /blog/${slug}`}
        </button>
        <button onClick={doPrefetch}>Prefetch /blog/{slug}</button>
      </div>

      <div style={{ marginBottom: 8 }}>
        <label>
          Docs path (catch-all):{" "}
          <input value={docsPath} onChange={(e) => setDocsPath(e.target.value)} />
        </label>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
        <button onClick={goToDocsCatchAll}>Go to /docs/{docsPath}</button>
        <button onClick={goToDashboardReports}>Go to /dashboard/reports</button>
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={goBack}>Back</button>
        <button onClick={goForward}>Forward</button>
        <button onClick={refreshPage}>Refresh</button>
      </div>
    </div>
  );
}