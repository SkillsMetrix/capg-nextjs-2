import PassengerCard from "@/app/components/PassengersCard"
import { fetchFlightByID, fetchPassengersByFlightID } from "@/app/lib/api"

export default async function FlightDetails({params}) {

    const {id}= params
    const flight= await fetchFlightByID(id)
    const passengers= await fetchPassengersByFlightID(id)
    
    return (
        <div>
             <h2>{flight.code}: Details</h2>  
             <div className="card">
                <div className="strong">{flight.from} -- {flight.to}</div>
                <div className="small">Duration: {flight.duration} * Seats: {flight.seats}</div>
                 <div className="small">Price: {flight.price} * Status: {flight.status}</div>

             </div>
             <h3> Passenger Details in this Flight</h3>
             <div className="grid">
                {passengers.length
                ? passengers.map(p => <PassengerCard key={p.id} passenger={p}/>)
                : <div className="card">No Passenger in this flight</div>
                }
             </div>

        </div>
    )
    
}