

'use client'
import styles from '../styles/App.module.css'
import UserItem from './User'

export default function UserList({users,onDelete,onRequestEdit}){
    if(!users.length) return <div className={styles.empty}>No User Saved Yet </div>

    return (
        <div>
        <h3>User Details</h3>
        <div className={styles.list}>
            {users.map(u => (
                <UserItem user={u} key={u.id} onDelete={onDelete} onRequestEdit={onRequestEdit}/>
            ))}
        </div>
        </div>
    )
}