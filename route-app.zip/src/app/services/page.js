import Image from "next/image";
 

export default function Services() {
  return (
    <div>
     service
     </div>
  )
}