'use client'

export default function PassengerCard({passenger}) {
    return (
        <div className="card">
            <div><strong>{passenger.name}</strong>
            <div className="small">Age: {passenger.age} * Flight: {passenger.flightId}</div></div>
        </div>
    )
}


