import AddFlight from "@/app/components/AddFlight";

 
 

export default function Home() {
  return (
    <div>
      <h2>Welcome add flights</h2>
       
       <AddFlight/>
        
    </div>
  );
}
