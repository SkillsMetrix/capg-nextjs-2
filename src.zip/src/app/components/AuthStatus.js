'use client'

import { signIn, signOut, useSession } from "next-auth/react"


export default function AuthStatus(){
    const {data: session,status}= useSession()
    if(status === 'loading') return <div style={{marginLeft:12}}>....</div>
    if(!session) return <button onClick={()=> signIn()}>signIn</button>

    return (
        <div style={{display: 'flex',gap:8,alignItems:'center'}}>
            <span className="small">{session.user?.email}</span>
             <button onClick={()=> signOut()}>signOut</button>
        </div>
    )
}