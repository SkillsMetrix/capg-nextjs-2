import Link from "next/link";

export default function FlightsLayout({children}){

    return(
        <section>
            <div style={{display:'flex', justifyContent:'space-between',alignItems:'center'}}>
                <h2>Flight Status</h2>
                <nav>
                    <Link href="/flights">All</Link>
                </nav>
            </div>
            <div>{children}</div>
        </section>
    )
}