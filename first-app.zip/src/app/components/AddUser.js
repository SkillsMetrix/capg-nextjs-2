'use client'

import { useState } from 'react'
import styles from '../styles/App.module.css'
export default function AddUser({onAdd}){

    const [username,setUsername]= useState('')
    const [email,setEmail]= useState('')
    const [city,setCity]= useState('')
const handleSubmit=(e)=>{
    e.preventDefault()
    if(!username.trim() || !email.trim() || !city.trim()) return alert('All Fields are required')
        onAdd({username:username.trim(),email:email.trim(),city:city.trim()})
        reset()
}
const reset=()=>{
    setUsername('')
    setEmail('')
    setCity('')
}

    return (
        <form className={styles.form} onSubmit={handleSubmit}>
            <input placeholder='Enter Username' value={username} onChange={(e)=> setUsername(e.target.value)} className={styles.input}></input>
              <input placeholder='Enter Email' value={email} onChange={(e)=> setEmail(e.target.value)} className={styles.input}></input>
                <input placeholder='Enter City' value={city} onChange={(e)=> setCity(e.target.value)} className={styles.input}></input>
                <div className={styles.controls}>
        <button className={styles.button}>Add</button>
             <button type='button' className={styles.button}>Reset</button>
             </div>
        </form>
    )
}
