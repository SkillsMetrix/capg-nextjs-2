import dynamic from "next/dynamic";
import { fetchFlights } from "../lib/api";
import { Suspense } from "react";
 
 
const FlightCard = dynamic(() => import('../components/FlightCard'),{
  loading: () => <div className="card">Loading Card...!</div>
})
export default async function FlightsPage() {

  let flights= await fetchFlights()
  
  return (
    <div>
      <div className="grid">
        {flights.map(f => (
          <Suspense key={f.id} fallback={<div className="card">Loading Flights....</div>}>
            <FlightCard flight={f}/>
          </Suspense>
        ))}
      </div>
        
       
      
       
    </div>
  );
}
