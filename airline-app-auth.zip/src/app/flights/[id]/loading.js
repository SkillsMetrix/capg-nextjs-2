

export default function PassengerDetailsLoading(){
    return <div className="card">Loading Passengers Details</div>
}