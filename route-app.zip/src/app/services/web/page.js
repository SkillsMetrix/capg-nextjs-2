import Image from "next/image";
 

export default function Web() {
  return (
    <div>
    Web service 🕸️
     </div>
  )
}