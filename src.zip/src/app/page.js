import Image from "next/image";
import styles from "./page.module.css";

export default function Home() {
  return (
    <div>
      <h2>Welcome to Airlines Booking App</h2>
      <p className="small">NewGen Flight Services</p>
      <div style={{marginTop:20}}>
        
      </div>
       
    </div>
  );
}
