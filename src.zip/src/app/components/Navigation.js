import Link from "next/link";
import styles from "./Navigation.module.css";

export default function Navigation() {
  return (
    <nav className={styles.navBar} aria-label="Main navigation">
      <ul className={styles.navList}>
        <li className={styles.navItem}>
          <Link className={styles.Link} href="/">
            Home
          </Link>{" "}
          |{" "}
        </li>
        <li className={styles.navItem}>
          <Link className={styles.link} href="/flights">
            Flights
          </Link>{" "}
          |{" "}
        </li>
        <li className={styles.navItem}>
          <Link className={styles.link} href="/passengers">
            Passengers
          </Link>{" "}
          |{" "}
        </li>
         <li className={styles.navItem}>
          <Link className={styles.link} href="/passengers/add">
            Add Passengers
          </Link>{" "}
          |{" "}
        </li>

         <li className={styles.navItem}>
          <Link className={styles.link} href="/flights/add">
            Add Flights
          </Link>{" "}
          |{" "}
        </li>
      </ul>
    </nav>
  );
}
