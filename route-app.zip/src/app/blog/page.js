  

export default function Blog() {
  return (
    <div>
 blog Page 🌬️
     </div>
  )
}


