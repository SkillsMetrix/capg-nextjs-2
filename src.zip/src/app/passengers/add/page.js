 

export default function Home() {
  return (
    <div>
      <h2>Welcome add Passengers</h2>
       
      
       
    </div>
  );
}
