import Image from "next/image";
 

export default function Web() {
  return (
    <div>
   Cloud service 🌨️
     </div>
  )
}