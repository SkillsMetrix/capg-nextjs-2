import Image from "next/image";
 

export default function Mobile() {
  return (
    <div>
    Mobile service 📲
     </div>
  )
}