import Image from "next/image";
import styles from "./page.module.css";
import ProgrammaticNav from "./components/ProgramNav";

export default function Home() {
  return (
    <div className={styles.page}>
     welcome Home 🏠
     <ProgrammaticNav/>
     </div>
  )
}