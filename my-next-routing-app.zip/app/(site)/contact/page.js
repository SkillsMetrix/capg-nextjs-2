export default function Contact() { return <h1>📞 Contact (Static)</h1>; }
