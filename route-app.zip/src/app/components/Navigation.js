import Link from "next/link";
import styles from "./Navigation.module.css";

export default function Navigation() {
  return (
    <nav className={styles.navBar} aria-label="Main navigation">
      <ul className={styles.navList}>
        <li className={styles.navItem}>
          <Link className={styles.Link} href="/">
            Home
          </Link>{" "}
          |{" "}
        </li>
        <li className={styles.navItem}>
          <Link className={styles.link} href="/about">
            About
          </Link>{" "}
          |{" "}
        </li>
        <li className={styles.navItem}>
          <span className={styles.link} tabIndex={0}>
            Services{" "}
          </span>
          <ul
            className={styles.dropdown}
            role="menu"
            aria-label="Service submenu"
          >
            <li>
              <Link className={styles.dropdownItem} href="/services/web">
                Web
              </Link> 
            </li>
            <li>
              <Link className={styles.dropdownItem} href="/services/mobile">
                Mobile
              </Link> 
            </li>
            <li>
              <Link className={styles.dropdownItem} href="/services/cloud">
                Cloud
              </Link> 
            </li>

            
          </ul>
        </li>
         <li className={styles.navItem}>
          <Link className={styles.link} href="/docs">
            Docs
          </Link>{" "}
          |{" "}
        </li>
      </ul>
    </nav>
  );
}
