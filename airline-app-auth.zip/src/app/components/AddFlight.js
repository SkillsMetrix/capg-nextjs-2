"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function AddFlight(){
    const router= useRouter()
    const [msg,setMsg]= useState('')
    const [busy,setBusy]= useState(false)

async function onSubmit(e) {
    e.preventDefault();
    setMsg('')
    setBusy(true)
    const fd= new FormData(e.currentTarget)
    const body=Object.fromEntries(fd.entries())
    body.seats= Number(body.seats || 0)
    body.price= Number(body.price || 0)

    try {
       const res= await fetch(`/api/flights`,{
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    })
    if(!res.ok) throw new Error('Failed to add')
      router.push('/flights')
    }catch(err){
      alert(err.message)
    }finally{
      setBusy(false)
    }
    
}
return (

    <form onSubmit={onSubmit} className="card" style={{display:'grid',gap:8}}>
        <h3>Add Flight</h3>
        <input name="code" placeholder="Enter Flight Code (AI101)" required/>
         <input name="from" placeholder="From (DEL)" required/>
          <input name="to" placeholder="To (BoB)" required/>
           <input name="duration" placeholder="Enter Duration (2h10m)" required/>
            <input name="price" type="number" placeholder="Enter Price" required/>
             <input name="seats" type="number" placeholder="Enter Seats" required/>
             <input name="status" placeholder="Flight Status" defaultValue="OnTime" required/>
        <button disabled={busy}>{busy ? 'Saving the FLight....!' : 'Add Flight'} </button>


    </form>
)

}