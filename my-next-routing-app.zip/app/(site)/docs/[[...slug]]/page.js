export default function DocsPage({ params }) {
  const slugArray = params?.slug;
  const isIndex = !slugArray || slugArray.length === 0;
  const path = isIndex ? "/docs" : `/docs/${slugArray.join("/")}`;

  return (
    <div>
      <h1>📚 Docs</h1>

      {isIndex ? (
        <>
          <p>This is the Docs index page. Path: <code>{path}</code></p>

          <h3>Example doc links</h3>
          <ul>
            <li><a href="/docs/intro">/docs/intro</a></li>
            <li><a href="/docs/getting-started/setup">/docs/getting-started/setup</a></li>
            <li><a href="/docs/api/v1/auth/login">/docs/api/v1/auth/login</a></li>
          </ul>

          <p>
            Note: this route uses an <strong>optional catch-all</strong> segment:
            <code>app/docs/[[...slug]]/page.js</code>
          </p>
        </>
      ) : (
        <>
          <p>Showing doc for: <strong>{path}</strong></p>
          <section>
            <h2>{slugArray[slugArray.length - 1]}</h2>
            <p>This is placeholder content for the doc at <code>{path}</code>.</p>
            <details>
              <summary>Raw params</summary>
              <pre>{JSON.stringify({ slug: slugArray }, null, 2)}</pre>
            </details>
          </section>
        </>
      )}
    </div>
  );
}
