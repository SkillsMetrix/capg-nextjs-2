import Link from "next/link";
import FlightFilterClient from "../components/FlightFilterClient";

export default function FlightsLayout({children}){

    return(
        <section>
            <div style={{display:'flex', justifyContent:'space-between',alignItems:'center'}}>
                <h2>Flight Status</h2>
                <nav>
                    <Link href="/flights">All</Link>{' | '}
                    <Link href="/flights?status=OnTime">ON Time</Link> {' | '}
                    <Link href="/flights?status=Delayed">Delayed</Link>
                </nav>
            </div>
            <FlightFilterClient/>
            <div>{children}</div>
        </section>
    )
}