
import Image from "next/image";
import styles from "./page.module.css";
import MainApp from "./components/MainApp";
// ssc

export default function Home() {
  return (
    <div>
      <p>Welcome to NextJS</p>
      <MainApp/>
      </div>

  )
}