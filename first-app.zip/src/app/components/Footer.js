

"use client"
    function Footer(props){
        return(
            <div>{props.fm}</div>
        )
    }

    export default Footer