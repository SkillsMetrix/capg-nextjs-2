import AddPassengerForm from "@/app/components/AddPassengerForm";

 

export default function Home() {
  return (
    <div>
      <h2>Welcome add Passengers</h2>
       
      <AddPassengerForm/>
       
    </div>
  );
}
