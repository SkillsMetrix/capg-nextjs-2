"use client";

import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function AddPassengerForm({ defaultFlightId = "" }) {
  const router = useRouter();
  const {data: session,status}= useSession()
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [flightId, setFlightId] = useState(defaultFlightId);
  const [saving,setSaving]= useState(false)

  if (status ==='loading'){
    return <div className="card"> Checking Authentication...!</div>
  }
  if(!session){
    return (
      <div className="card">
        <h3>Signin Required</h3>
        <p className="small">You Must Signin to add the Passenger</p>
        <div style={{marginTop: 8}}>
          <button onClick={()=> signIn()}>signIn</button>
        </div>
      </div>
    )
  }
  async function handleSubmit(e){
    e.preventDefault()
    setSaving(true)
    try {
       const res= await fetch(`/api/passengers`,{
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({name,age: Number(age),flightId: Number(flightId)})
    })
    if( res.status === 401){
      alert('Unauthorized , Please signin to access')
      signIn()
      return
    }
    if(res.status == 403){
      alert('Forbidden...! your account doesnt allow to add this')
      return
    }
    if(!res.ok) throw new Error('Failed to add')
      router.push('/passengers')
    }catch(err){
      alert(err.message)
    }finally{
      setSaving(false)
    }
    
    

  }

  return (
 
        <form onSubmit={handleSubmit} className="card">
            <h3>Add Passengers</h3>
            <div style={{display:'grid', gap:8}}>
                <input type='text' value={name} onChange={e => setName(e.target.value)} placeholder="Enter Name" required/>
                 <input type='text' value={age} onChange={e => setAge(e.target.value)} placeholder="Enter Age" required/>
                  <input type='text' value={flightId} onChange={e => setFlightId(e.target.value)} placeholder="Enter FlightID" required/>
                  <button disabled={saving}>{saving ? 'Saving the Passenger....!' : 'Add Passenger'} </button>
            </div>
        </form>
 
  )
}
